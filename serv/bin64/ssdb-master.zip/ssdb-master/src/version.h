#ifndef SSDB_DEPS_H
#ifndef SSDB_VERSION
#define SSDB_VERSION "1.8.0"
#endif
#endif
#include <stdlib.h>
#include <jemalloc/jemalloc.h>
